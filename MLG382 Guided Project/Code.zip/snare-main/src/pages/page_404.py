from dash import html

def get_404_page():
	return html.P("404")